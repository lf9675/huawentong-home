window.LESSON_WORDS={
  "葡萄": {
    "meaning": "一种一串串生长、可以食用的果实。",
    "en": "grape",
    "paragraph": 1
  },
  "象征": {
    "meaning": "用事物或动作表达某种意义。",
    "en": "symbolise",
    "paragraph": 1
  },
  "事事如意": {
    "meaning": "每件事情都合乎心意。",
    "en": "everything goes as wished",
    "paragraph": 1
  },
  "按照": {
    "meaning": "根据；依照。",
    "en": "according to",
    "paragraph": 2
  },
  "风俗": {
    "meaning": "某个地方长期形成的生活习惯。",
    "en": "custom",
    "paragraph": 2
  },
  "辞旧迎新": {
    "meaning": "告别旧的一年，迎接新的一年。",
    "en": "bid farewell to the old and welcome the new",
    "paragraph": 2
  },
  "夜幕降临": {
    "meaning": "天色暗下来，夜晚到来。",
    "en": "night falls",
    "paragraph": 3
  },
  "燃放": {
    "meaning": "点燃烟火等，让它燃烧或爆发。",
    "en": "set off",
    "paragraph": 3
  },
  "烟火": {
    "meaning": "燃放时发出火花、光彩的物品。",
    "en": "fireworks",
    "paragraph": 3
  },
  "翩翩起舞": {
    "meaning": "轻快、优美地跳舞。",
    "en": "dance gracefully",
    "paragraph": 3
  },
  "瓶瓶罐罐": {
    "meaning": "各种瓶子和罐子。",
    "en": "bottles and jars",
    "paragraph": 3
  },
  "去除": {
    "meaning": "除掉；去掉。",
    "en": "remove",
    "paragraph": 3
  },
  "烦恼": {
    "meaning": "让人不快乐、心里不安的事情或心情。",
    "en": "worry",
    "paragraph": 3
  },
  "厄运": {
    "meaning": "不幸的遭遇；坏运气。",
    "en": "misfortune",
    "paragraph": 3
  },
  "前夕": {
    "meaning": "某个日子前的夜晚或前一段时间。",
    "en": "eve",
    "paragraph": 4
  },
  "堆放": {
    "meaning": "把东西集中放在一起。",
    "en": "pile up",
    "paragraph": 4
  },
  "预示": {
    "meaning": "事先显示某种将会出现的情况。",
    "en": "indicate in advance",
    "paragraph": 4
  },
  "兆头": {
    "meaning": "预先显露的迹象。文中“好兆头”指好运的迹象。",
    "en": "omen",
    "paragraph": 4
  },
  "忙碌": {
    "meaning": "事情多，忙着做事。",
    "en": "busy",
    "paragraph": 5
  },
  "路途": {
    "meaning": "出行所走的路或旅程。",
    "en": "journey",
    "paragraph": 5
  },
  "遥远": {
    "meaning": "距离很远。",
    "en": "far away",
    "paragraph": 5
  },
  "团聚": {
    "meaning": "分开的人重新聚在一起。",
    "en": "reunite",
    "paragraph": 5
  },
  "恭敬": {
    "meaning": "对人有礼貌、很尊重。",
    "en": "respectful",
    "paragraph": 5
  },
  "长辈": {
    "meaning": "辈分比自己高的人。",
    "en": "elder",
    "paragraph": 5
  },
  "亲戚": {
    "meaning": "和自己有血缘或婚姻关系的人。",
    "en": "relative",
    "paragraph": 5
  },
  "祝福": {
    "meaning": "表达希望别人幸福、顺利的心愿。",
    "en": "give good wishes",
    "paragraph": 5
  },
  "诸事大吉": {
    "meaning": "各件事情都吉利、顺利。",
    "en": "good fortune in all things",
    "paragraph": 5
  }
};
