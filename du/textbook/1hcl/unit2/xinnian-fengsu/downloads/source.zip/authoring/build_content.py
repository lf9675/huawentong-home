from pathlib import Path
import json
OUT=Path(__file__).resolve().parent.parent
P=[
'当教堂的钟声在午夜12点响起时，大家都争着吃葡萄，如果能跟着钟声连续吃下12颗，就象征新的一年12个月都事事如意。',
'按照当地风俗，每人准备一碗清水，等午夜钟声敲响后，各自把水泼到窗外，以示辞旧迎新。',
'夜幕降临，人们在街头燃放烟火，翩翩起舞。到了午夜时分，家家户户把旧的瓶瓶罐罐扔出窗外，表示去除烦恼和厄运。',
'新年前夕，人们把平时打碎的杯盘碗碟偷偷送到朋友家的门前。谁家堆放的碎片多，就说明谁家的朋友多，也预示着来年的好兆头。',
'农历新年来临前，华人会在家里大扫除，辞旧迎新。除夕夜，不管工作多忙碌，路途多遥远，大家都要回家团聚，开开心心地围坐在一起吃团圆饭。大年初一，人们恭敬地给长辈和亲戚拜年，互相祝福，希望在新的一年身体健康，诸事大吉。']
labels=['西班牙','古巴','意大利','丹麦','世界各地的华人']
rows=[
{'id':'spain','time':'午夜12点，教堂钟声响起时','action':'跟着钟声连续吃下12颗葡萄','meaning':'祝愿新的一年12个月都事事如意','panels':[1,2,3],'role':'教师示范（我做）','obstacle':'象征、事事如意；12颗与12个月的对应','evidence':P[0],'explain':'把“吃葡萄”与“美好愿望”分开。十二颗葡萄对应十二个月，表达祝愿，并非保证每个月一定顺利。','reject':'只写“吃葡萄”漏了时间与数量；把象征当成一定实现的结果。'},
{'id':'cuba','time':'午夜钟声敲响后','action':'把准备好的一碗清水泼到窗外','meaning':'表示辞别旧年，迎接新年','panels':[4,5,6],'role':'师生共构（我们做）','obstacle':'按照、以示、辞旧迎新','evidence':P[1],'explain':'“准备一碗清水”是准备动作；钟响后泼水才是迎新方式。“以示”后面说明寓意。','reject':'只写“准备清水”没有写出迎新动作；与意大利抛瓶罐混淆。'},
{'id':'italy','time':'夜幕降临；午夜时分','action':'先燃放烟火、跳舞；午夜扔旧瓶罐','meaning':'表示去除烦恼和厄运','panels':[7,8,9],'role':'学生独立（你做）','obstacle':'夜幕降临、翩翩起舞、厄运；两个时间点','evidence':P[2],'explain':'这一段有两个时间点。夜幕降临时燃放烟火、跳舞；午夜扔旧瓶罐，寓意去除烦恼和厄运。','reject':'把“朋友多”当成意大利风俗的寓意；漏掉夜晚与午夜的先后。'},
{'id':'denmark','time':'新年前夕','action':'把平时打碎的杯盘碗碟送到朋友门前','meaning':'碎片多表示朋友多，并预示好兆头','panels':[10,11,12],'role':'学生独立（你做）','obstacle':'前夕、预示、兆头；“谁……就……”的关系','evidence':P[3],'explain':'课文写的是送“平时打碎”的杯盘碗碟，并没有写为了送朋友而特意打碎。碎片数量在风俗中代表朋友多及好兆头。','reject':'解释成朋友故意破坏物品；只答“垃圾多”，忽略课文的象征意思。'},
{'id':'chinese','time':'新年前；除夕夜；大年初一','action':'大扫除；回家吃团圆饭；向长辈亲戚拜年','meaning':'辞旧迎新，祝愿身体健康、诸事大吉','panels':[13,14,15,16],'role':'学生独立（你做）','obstacle':'忙碌、遥远、恭敬；不管……都……；三个时间点','evidence':P[4],'explain':'按“新年前—除夕夜—大年初一”整理。回家团聚体现珍惜亲情；“希望”提醒我们：祝福是愿望，不是保证。','reject':'把所有活动都写在大年初一；把农历新年当成阳历1月1日。'}]
actions=[
['每月第一天，吃下十二颗葡萄','午夜钟响时，连续吃十二颗葡萄','午夜钟响后，向窗外泼一碗清水','新年前夕时，把碎碗碟送到门前'],
['午夜钟响时，连续吃十二颗葡萄','午夜钟响前，把清水送朋友门前','午夜钟响后，把旧瓶罐扔向窗外','午夜钟响后，把一碗水泼向窗外'],
['夜晚放烟火跳舞，午夜扔掉旧瓶罐','夜晚准备清水，午夜泼到窗户外','夜晚收集碎片，午夜送朋友门前','夜晚团聚吃饭，午夜向长辈拜年'],
['午夜时分，把旧瓶罐扔到街道上','新年前夕，把清水送到朋友门前','新年前夕，把碎碗碟送到朋友门前','新年初一，把碎碗碟送到长辈门前'],
['新年前大扫除，除夕团圆饭，初一拜年','新年前拜年，除夕大扫除，初一团圆饭','新年前团圆饭，除夕拜年，初一大扫除','新年前大扫除，除夕拜年，初一团圆饭']]
meanings=[
['表示亲朋好友将在新年团聚','表示将旧年的烦恼厄运去除','表示新的一年朋友将会更多','祝愿新的一年每个月都如意'],
['庆祝一年中家里的用水充足','表示辞别旧年并且迎接新年','说明主人拥有许多亲朋好友','预祝新一年每个月都有收成'],
['预示新的一年会有更多朋友','表示家人团圆并且互相祝福','表示去除旧年的烦恼和厄运','庆祝家里准备了许多新瓶罐'],
['表示朋友众多并预示来年好运','表示家人团聚并互相送上祝福','表示去除过去所有烦恼和厄运','表示辞别旧年并迎接新的月份'],
['表示要丢掉旧物并增添新家具','辞旧迎新并祝愿健康诸事大吉','表示碎片越多主人朋友就越多','用十二颗葡萄祝愿各月都如意']]
ai=[1,3,0,2,0];mi=[3,1,2,0,1]
tasks=[]
for i,r in enumerate(rows):
    p=i+1
    tasks.append(dict(id=r['id'],title=f'{p} · {labels[i]}',lesson=1,order=p,range=[p],focus=[p],mode='objective',required=True,requiredMessage='请先完成本段的两项选择。',questions=['根据课文内容，填写下面的表格。'],keywords=['根据课文内容','填写'],source=f'课本《阅读放大镜》第二题，第{p}段小步骤。原表的共同象征意义在第6步归纳。',guide='先口头说出时间，再选择迎新方式和具体寓意。',conceptNotes=[['象征意义','借一个动作或事物表达愿望（symbolic meaning）。']] if i==0 else [],fields=[dict(id='action',label='迎接新年的方式',type='select',options=actions[i],correct=actions[i][ai[i]]),dict(id='meaning',label='本段的具体寓意',type='select',options=meanings[i],correct=meanings[i][mi[i]])],hints=[f'回看第{p}段，把“做什么”和“表示什么”分开。',f'留意这些词：'+['午夜12点、连续、象征','钟声敲响后、泼、以示','夜幕、午夜、表示','平时打碎、朋友多、预示','新年前、除夕夜、大年初一、希望'][i]],answer=f'时间：{r["time"]}。\n方式：{r["action"]}。\n寓意：{r["meaning"]}。',explain=r['explain'],reject=r['reject'],points=['我分清了迎新动作与象征意义。','我能回到原文指出依据。'],role=r['role'],target='提取信息；区分做法与寓意；保留时间条件',scoreGuide='形成性练习。方式、寓意各1点，独立核对，共2点；不设连带清零。网页首次正确率按整组两项均正确计算。',evidenceText=r['evidence'],distractorNotes=['时间或动作张冠李戴。','把其他地区的寓意移到本地区。','只抓物件，忽略文中“象征／以示／表示／预示／希望”后的信息。']))
tasks.extend([
dict(id='common',title='6 · 不同方式，共同愿望',lesson=1,order=6,scope='full',range=[1,5],focus=[5],mode='written',required=True,requiredMessage='请写出共同点，并说明两个例子怎样支持它。',questions=['根据课文内容，填写下面的表格。','各地迎接新年的方式有什么共同的象征意义？请用两处课文内容说明。'],keywords=['共同','象征意义','两处','说明'],source='课本《阅读放大镜》第二题右栏＋教参2.3的共同点追问；证据解释为教师补充。',guide='先写共同愿望，再用两个地方的做法说明。',conceptNotes=[['共同点','找不同做法背后的相同愿望。']],evidence=[{'label':'两处原文依据（可回看第1—5段，连续加入多句）'}],fields=[{'id':'response','label':'我的答案（两三句）','placeholder':'共同点是……。例如，……；……。这说明……。'}],hints=['比较每段表示愿望的词，不只比较使用什么东西。','留意“事事如意、辞旧迎新、去除厄运、好兆头、诸事大吉”。选两个地方说明。'],answer='这些风俗都寄托了人们辞旧迎新、祝愿新一年生活美好的愿望。例如，西班牙人吃12颗葡萄，祝愿12个月事事如意；华人向长辈和亲戚拜年，祝愿大家健康、诸事大吉。这些做法不同，却都表达了对新年的美好期盼。',explain='共同点要能概括几个地区。动作、物品可以不同；把具体做法与美好愿望联系起来，才算解释。',reject='只写“都很有趣／都吃东西／都在午夜”，无法概括全文；只列举两种做法而不说明寓意；声称风俗能保证好运。',points=['我写出共同愿望。','我用了两个地方的准确例子。','我解释了例子与共同愿望的联系。'],role='学生独立（你做）',target='跨段整合；证据支持概括；完整短答',evidenceText='任选两段与寓意相关的完整原句。',scoreGuide='教师参考4点：共同愿望1点；两个准确例子各1点；解释例子与愿望的联系1点。各点独立给分，不以字数评分。'),
dict(id='collocation',title='7 · 词语搭配',lesson=1,order=7,scope='full',range=[1,5],focus=[5],mode='objective',required=True,requiredMessage='请完成五组搭配。',questions=['根据课文内容，把可以搭配的词语连起来。'],keywords=['根据课文内容','搭配'],source='课本《阅读放大镜》第一题。点选代替画线，五组原题全部保留。',guide='每个词语选一个搭配。可以回看原文。',bank=['厄运','烟火','遥远','忙碌','风俗'],blanks=[{'id':'work','before':'工作','after':'','correct':'忙碌'},{'id':'journey','before':'路途','after':'','correct':'遥远'},{'id':'follow','before':'按照','after':'','correct':'风俗'},{'id':'remove','before':'去除','after':'','correct':'厄运'},{'id':'fireworks','before':'燃放','after':'','correct':'烟火'}],hints=['先分清：前面的词在说状态，还是一个动作？','“工作、路途”后接状态；“按照、去除、燃放”后接相应事物。再核对第2、3、5段。'],answer='工作—忙碌；路途—遥远；按照—风俗；去除—厄运；燃放—烟火。',explain='工作怎样？忙碌。路途怎样？遥远。按照什么？风俗。去除什么？厄运。燃放什么？烟火。把词放回原句，检查意思是否通顺。',reject='按词表位置机械配对；把“工作遥远”或“燃放风俗”当成通顺搭配。',points=['我能把五组搭配放回原句读通。'],role='学生独立（你做）',target='词语搭配与语境运用',evidenceText='第2段“按照当地风俗”；第3段“燃放烟火”“去除烦恼和厄运”；第5段“工作多忙碌”“路途多遥远”。',scoreGuide='教师参考5点，每组1点。网页整组五项全对才计首次正确；不得把这个百分比当成逐空得分。'),
dict(id='share',title='8 · 查一查，说清为什么',lesson=1,order=8,scope='full',range=[1,5],focus=[5],mode='written',required=True,requiredMessage='请写下资料出处和分享，并说明为什么。',questions=['还有哪些有趣的迎接新年的方式，上网搜一搜，和同学分享。','你为什么觉得这种方式有趣？它的做法怎样表达新年愿望？'],keywords=['哪些','上网搜一搜','分享','为什么','怎样'],source='课本《阅读放大镜》第三题；“为什么／怎样表达愿望”为教师补充追问。',guide='查一种课文以外的风俗。写三四句后，与同桌分享。',conceptNotes=[['看法','哪种风俗有趣？'],['理由','为什么有趣？'],['例子','具体什么时候、做什么？'],['回扣','这个做法怎样表达愿望？']],resources=[{'label':'资料入口：日本国家旅游局','url':'https://www.japan.travel/en/sg/story/new-year-food-traditions/'}],fields=[{'id':'source','label':'资料出处（机构或网站名称＋网址）','placeholder':'可复制资料网址。'},{'id':'share','label':'我的分享（风俗、理由、例子、回扣）','placeholder':'我觉得……很有趣，因为……。例如……。这个做法表达了……。'}],hints=['先核对资料是谁发布的，再找时间、做法和寓意。可使用已提供的资料入口。','不能只写“因为很有趣”。想想：物品的形状、数字或动作怎样表达愿望？'],answer='我觉得日本人在新年前夜吃荞麦面很有趣，因为面条的形状也能表达祝福。例如，细长的面条让人联想到长寿。人们借吃面条祝愿长寿，表达了对美好生活的期盼。资料：日本国家旅游局《New Year food traditions》。',explain='这是一种合理示范，不是唯一答案。介绍别的风俗也可以，但要有可核对的资料，并解释做法与寓意的联系。',reject='资料没有出处；只说“很好玩”而无理由；照抄长篇网页；把象征长寿写成吃面就一定长寿。',points=['我有可信、可打开的资料出处。','我说清时间和具体做法。','我解释为什么有趣。','我把做法与新年愿望联系起来。'],role='学生独立（你做）＋同桌分享',target='资料检索；准确转述；开放解释',evidenceText='资料入口已核对：JNTO，2018-12-21，2026-10-22查阅。学生选择其他来源时由教师覆核。',scoreGuide='教师参考4点：资料与事实准确1点；做法具体1点；理由明确1点；解释做法与愿望的联系1点。接受其他有根据的风俗。主观题不自动打分。')])
rects=[[10,146,497,423],[518,146,496,423],[10,580,497,448],[518,580,496,448],[10,1036,497,486],[518,1036,496,486]]*3
L=dict(id='s1u2l1',title='世界各地的新年风俗',label='中一高级华文 · 单元二 · 生活空间',grade=1,unit=2,version='20261022-1',sequenceVersion=1,paragraphs=P,paragraphLabels=labels,paragraphIdeas=[r['action']+'，'+r['meaning']+'。' for r in rows],paragraphTasks=[r['id'] for r in rows],panelRects=rects,panelSheets=[i//6+1 for i in range(18)],panels=[r['panels'] for r in rows],tasks=tasks,simpleTaskGuide=True,figures={'5':{'kind':'table','title':'课本小知识：元旦与春节','headers':['节日','日期'],'rows':[['元旦','阳历1月1日'],['春节','农历正月初一']],'note':'农历新年也叫“春节”。'}},rows=rows,summaryTask='common',summaryColumns=[{'key':'action','label':'迎接新年的方式'},{'key':'meaning','label':'具体寓意'}],summaryItems=[{'id':r['id'],'name':labels[i]} for i,r in enumerate(rows)],objectiveSuccess='两项信息已核对，请再对照原文。',accuracyLabel='客观任务首次全部答对率',duration=50,flow=[['导入',3,'口头交流熟悉的迎新方式；不增加书面题。'],['自主图文阅读',7,'按第1—5段阅读原文与原漫画，按需查词。'],['原表逐段取信息',17,'西班牙教师示范，古巴共同完成，其余三段独立；先说时间，再点选方式与寓意。'],['共同象征意义',6,'独立短答，引用两个地区说明；教师抽样核对。'],['词语搭配',5,'课本第一题五组搭配，错后回读订正。'],['查资料并分享',9,'课本第三题，查一种风俗，写三四句并与同桌分享；说明为什么。'],['当堂检查',3,'订正，整理个人词语，导出记录。']],goals=['从各段提取时间、迎新方式与具体寓意。','用两个准确例子说明不同风俗背后的共同愿望。','完成原题搭配，并借可信资料解释一种新年风俗。'],sources=[{'title':'教师提供的课文、阅读放大镜、教参截图及三张原漫画','type':'用户附件'},{'title':'New Year food traditions — Japan National Tourism Organization','url':'https://www.japan.travel/en/sg/story/new-year-food-traditions/','published':'2018-12-21','checked':'2026-10-22'}])
L['objectiveSuccess']='回答已核对，请再对照原文和解释。'
for task in tasks:
    for blank in task.get('blanks',[]):
        blank['answer']=blank.pop('correct')
(OUT/'lesson.json').write_text(json.dumps(L,ensure_ascii=False,indent=2))
(OUT/'content.js').write_text('window.LESSON='+json.dumps(L,ensure_ascii=False,separators=(',',':'))+';\nwindow.HWT_WORD_CONTEXT=()=>({lessonId:LESSON.id,lessonTitle:LESSON.title,grade:1,unit:2,paragraphs:LESSON.paragraphs});\nwindow.HWT_WORD_LEXICON=()=>window.LESSON_WORDS;\n')
vocab=[('葡萄','一种一串串生长、可以食用的果实。','grape'),('象征','用事物或动作表达某种意义。','symbolise'),('事事如意','每件事情都合乎心意。','everything goes as wished'),('按照','根据；依照。','according to'),('风俗','某个地方长期形成的生活习惯。','custom'),('辞旧迎新','告别旧的一年，迎接新的一年。','bid farewell to the old and welcome the new'),('夜幕降临','天色暗下来，夜晚到来。','night falls'),('燃放','点燃烟火等，让它燃烧或爆发。','set off'),('烟火','燃放时发出火花、光彩的物品。','fireworks'),('翩翩起舞','轻快、优美地跳舞。','dance gracefully'),('瓶瓶罐罐','各种瓶子和罐子。','bottles and jars'),('去除','除掉；去掉。','remove'),('烦恼','让人不快乐、心里不安的事情或心情。','worry'),('厄运','不幸的遭遇；坏运气。','misfortune'),('前夕','某个日子前的夜晚或前一段时间。','eve'),('堆放','把东西集中放在一起。','pile up'),('预示','事先显示某种将会出现的情况。','indicate in advance'),('兆头','预先显露的迹象。文中“好兆头”指好运的迹象。','omen'),('忙碌','事情多，忙着做事。','busy'),('路途','出行所走的路或旅程。','journey'),('遥远','距离很远。','far away'),('团聚','分开的人重新聚在一起。','reunite'),('恭敬','对人有礼貌、很尊重。','respectful'),('长辈','辈分比自己高的人。','elder'),('亲戚','和自己有血缘或婚姻关系的人。','relative'),('祝福','表达希望别人幸福、顺利的心愿。','give good wishes'),('诸事大吉','各件事情都吉利、顺利。','good fortune in all things')]
words={}
for w,m,en in vocab:
    p=next((i+1 for i,t in enumerate(P) if w in t),None)
    assert p,w
    words[w]={'meaning':m,'en':en,'paragraph':p}
(OUT/'lexicon.js').write_text('window.LESSON_WORDS='+json.dumps(words,ensure_ascii=False,separators=(',',':'))+';\n')
assert sum(x[1] for x in L['flow'])==50
assert len(tasks)==8 and len([t for t in tasks if t['mode']=='written'])==2
print('Content:',len(P),'paragraphs;',len(tasks),'tasks;',len(words),'words; 50 minutes')
