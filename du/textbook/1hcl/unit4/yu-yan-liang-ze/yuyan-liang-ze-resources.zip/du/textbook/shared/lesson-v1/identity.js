/* Uses the shared lesson record; no separate student identity store. */
(()=>{const host=document.querySelector('#topIdentity'),state=()=>window.LessonEngine.state(),key=window.LESSON_STORAGE_KEY||'huawentong-lesson-'+window.LESSON.id+'-v1';for(const [name,label]of [['name','姓名'],['class','班级'],['number','学号／组别']]){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.maxLength=60;i.value=state().identity[name]||'';i.setAttribute('aria-label',label);i.oninput=()=>{state().identity[name]=i.value;try{localStorage.setItem(key,JSON.stringify(state()));document.querySelector('#saveState').textContent='已保存'}catch{document.querySelector('#saveState').textContent='保存失败，请导出记录'}};l.append(i);host.append(l)}window.addEventListener('hashchange',()=>{host.querySelectorAll('input').forEach((i,n)=>i.value=state().identity[['name','class','number'][n]]||'')})})();



